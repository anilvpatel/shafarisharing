var myapp = angular.module("blogapp",[]);

myapp.controller("blogctrl",function($scope, $http){
      
    var pageno = document.getElementById('pageno').innerHTML;
    var ctype = document.getElementById('type').innerHTML;
    var burl = document.getElementById('baseurl').innerHTML; 
    
    if(ctype == 'all'){
    	$scope.all = 1
    }else{
    	$scope.all = 0
    }
    //call blog category
    $http({
        method: 'post',
        url:  burl+'/blog/getblogcategory/'
    }).then(function(response){        	 
        if (response.data.status == "success"){ 
             var result = response.data.result; 
        	 $scope.category = [];
             for(var x=0; x<result.length; x++){
             	   
             	   if(result[x].category_slug == ctype){
             	   	 result[x].active = 1;
             	   }else{
             	   	 result[x].active = 0;
             	   }             	   
                   $scope.category.push(response.data.result[x]);
             }       	
        }   
    })
     
    $http({
        method: 'post',
        url: burl+'/blog/getblogdata/',
        data: {
        	page : pageno,
            type : ctype
        }
    }).then(function(response){  

        if (response.data.status == "success"){ 
        	 $scope.blogs = response.data.result;  
             //addBtnListner();
        	 //$scope.filterSelection(ctype); //It should be call after all column div will initalize
        }   
    })


    $scope.changeCategory = function(c){

    	if(c != ctype){  //Present type is different from select type then starts from page 1
    		pageno = 1;
    	}

    	$scope.changeurl = burl+'blog/'+pageno+'/'+c;
	    location.replace($scope.changeurl);
    }

    // Add active class to the current button (highlight it)
  //   function addBtnListner() {
  //   	var btnContainer = document.getElementById("myBtnContainer");
		// var btns = btnContainer.getElementsByClassName("btn-grid");		
		// for (var i = 0; i < btns.length; i++) {
		//     btns[i].addEventListener("click", function(){ 
		//     var showbtn = document.getElementsByClassName("left-btn");
		//     showbtn[0].className = showbtn[0].className.replace(" left-btn", "");
		//     var current = document.getElementsByClassName("active");
		//     current[0].className = current[0].className.replace(" active", "");
		//     this.className += " active";
		//     this.className += " left-btn";	    
		//   });
		// }  
  //   }


    

    //Filter Blog Data According to category slug
	// $scope.filterSelection = function(c) { 		 
       
      

	//   var x, i;
	//   x = document.getElementsByClassName("column");

	//   //if length of tips/insight/safaring //Category is less than 6(length of no. of blog //length of array calls more data)
	//   y = document.getElementsByClassName(c); //it gives number of particular category_slug have in all
	//   console.log(y.length); //gives the length
 //      $scope.clength = y.length;
	//   if( c != 'all' && y.length < 6){
	//   	bringmore(c);
	//   } 

	//   if (c == "all") c = "";
	//   for (i = 0; i < x.length; i++){ 
	//     w3RemoveClass(x[i], "show");
	//     if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
	//   }
	// }

	// function bringmore(c){     
	//      $http({
	//         method: 'post',
	//         url: 'http://localhost/safarisharing/blog/getblogdata/',
	//         data:{
	//         	 page : pageno,
 //                 type : c,
 //                 typelength: $scope.clength
	//         }
	//      }).then(function(response){        	 
	//         if (response.data.status == "success"){  
	//              console.log("bringmore"); 
	//              console.log(response.data.result);  
	//              for(var x= 0; x<response.data.result.length; x++){
 //                    $scope.blogs.push(response.data.result[x]); 
	//              }   
	//         }   
	//      }) 
	// }
	
	
	
  
	// function w3AddClass(element, name) {
	// 	//alert("add");
	//   var i, arr1, arr2;
	//   arr1 = element.className.split(" ");
	//   arr2 = name.split(" ");
	//   for (i = 0; i < arr2.length; i++) {	  	
	//     if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
	//   }
	// }
	
	// function w3RemoveClass(element, name) {
	// 	//alert("remove");
	//   var i, arr1, arr2;
	//   arr1 = element.className.split(" ");
	//   arr2 = name.split(" ");
	//   for (i = 0; i < arr2.length; i++) {
	//     while (arr1.indexOf(arr2[i]) > -1) {
	//       arr1.splice(arr1.indexOf(arr2[i]), 1);     
	//     }
	//   }
	//   element.className = arr1.join(" ");
	// }
 
});