<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_faq extends CI_Model {

    function __construct(){

		parent::__construct();
		$this->load->database();
	}

	function active_faq_category($table){ 

		$this->db->select('*'); //'*' if you want to select all 'column1,column2'
        $this->db->from($table); //from review table 
        //Review active & display according to position
        $this->db->where("active='1'");
		$this->db->order_by('position', 'ASC'); 

		$query = $this->db->get();
        return $query->result(); 
	}

	function get_category_details($c_id){  //$c_id is cateogry id 
       
        $this->db->select('*'); //'*' if you want to select all 'column1,column2'  
        $this->db->from('faq'); //from review table 
        //Review active & display according to position
        $where = array(
              "active" => 1,
              "faq_category" => $c_id
        );
        $this->db->where($where);         
		$this->db->order_by('faq_position', 'ASC'); 
           
        $query = $this->db->get();
        return $query->result();  
	}

	function send_result(){  //Make Complete Result Here //how data structure you want according...
       
       $faq_cateogry = $this->active_faq_category('faq_category'); //get category details         
         
	    foreach ($faq_cateogry as $key => $value) {               
	           $c_id = $value->id; //take id 
	           $value->category_name = strtoupper($value->category_name);
	           //Retrieve category QA value depends on cat_id  //Make QA new member of object for each cateogry 
	           $value->QA = $this->get_category_details($c_id);	                  	 
	    } 

	    return $faq_cateogry;

	}

}