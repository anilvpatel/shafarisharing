 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_blog extends CI_Model {

    function __construct(){

		parent::__construct();
		$this->load->database();
	}

    function retrieveBlog($no,$type,$typelength){ //$no no of blog //$type of blog

        $total = $this->perPage(); //get perPage value //View field $field        

        if($no > 0 && is_numeric($no)){
           $skip = ($no-1)*$total;
        }else{
           $skip = 0;
        }
        
        if(!empty($typelength)){
        	$skip = $skip + $typelength; //total Skip is equal to typelength + skip per page
        	$total = $total - $typelength;
        }

        $this->db->select('*'); //'*' if you want to select all 'column1,column2'
        $this->db->from('blog'); //from blog table         
        $this->db->join('blog_category', 'blog_category.id = blog.b_category'); 
        //Review active & display according to date published 
        $where = array('b_status' => '2', 'category_slug' => $type); 
        if($type == 'all') { //Do not depend on type of category
           $where = array('b_status' => '2');
        }             
        $this->db->where($where);
        $this->db->order_by('b_date', 'DESC');
        $this->db->limit($total,$skip);
        $query = $this->db->get();
        return $query->result(); 
    }

    function retrieveSingleBlog($url){

    	$field = array('blog.id','b_title','b_content','b_date','b_f_img','b_view','category_name');
        $this->db->select($field); //'*' if you want to select all 'column1,column2'
        $this->db->from('blog'); //from blog         
        $this->db->join('blog_category', 'blog_category.id = blog.b_category'); 
        //Review active & display according to date published
        $where = array('b_status' => '2', 'b_link' => $url);
        $this->db->where($where);        
        $query = $this->db->get();
        $row = $query->row();  //Single Row
        return $row; 

    }

    function recentBlog($no,$id){ //$id has to be skip since that single post is open in browser
        $field = array('b_title','b_link','b_date','b_f_img','b_view','category_name');
        $this->db->select($field); //'*' if you want to select all 'column1,column2'
        $this->db->from('blog'); //from blog         
        $this->db->join('blog_category', 'blog_category.id = blog.b_category'); 
        //Review active & display according to date published
        $where = array('b_status' => '2','blog.id !=' => $id);
        $this->db->where($where);        
        $this->db->order_by('b_date', 'DESC');  
        $this->db->limit($no);

        $query = $this->db->get();
        return $query->result(); 
    }


	function perPage(){     
        
   	    $query = $this->db->query("SELECT option_value FROM options WHERE option_name ='blog_per_page'");
		$row = $query->row();
		$blog_per_page = intval($row->option_value);
        return $blog_per_page;
    }

	//Get total no of blog in database
    function totalRow($table,$type = 'all'){ 
    	
        $this->db->join('blog_category', 'blog_category.id = blog.b_category'); 
	    $where = array('b_status' => '2', 'category_slug' => $type); 
	    if($type == 'all') { //Do not depend on type of category
	       $where = array('b_status' => '2');
	    }  
		$this->db->where($where);
		return $this->db->count_all_results($table);        
    }


    function totalPage($type){
    
        $total_review = $this->totalRow('blog',$type);  //Total no. of review
        $per_page = $this->perPage();  //No of review To display per page
        $no_of_pages = $total_review/$per_page;  
        $itr = $no_of_pages - intval($no_of_pages); //if itr is greater than zero than //Even Odd Problem of per page review
        if($itr > 0){
        	$totalpage = intval($no_of_pages)+1;
	    }else{
	        $totalpage = intval($no_of_pages);
	    } 

       return $totalpage; 
  }

    function blogCategory($table){
    	$this->db->select('*');
    	$this->db->from($table);
    	$query = $this->db->get();
    	return $query->result();
    }
     


   // this function is used to insert Fake Data
    function insertFakeData($options = array()) {
		$this->db->insert('blog', $options);
	}
	function truncate()
	{
		$this->db->truncate('blog');
	}
    
}