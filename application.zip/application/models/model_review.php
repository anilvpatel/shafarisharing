<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_review extends CI_Model {

    function __construct(){

		parent::__construct();
		$this->load->database();

        //public $table = 'review';
		 // $this->db->join('comments', 'comments.id = blogs.id', 'left');  

        //$array = array('id' => 2, 'title' => $title, 'status' => $status); //By Default AND
        //$this->db->where($array);   //If you want to specific table $query = $this->db->get_where($table, array('id' => $id));
        // custom string also $where = "name='Joe' AND status='boss' OR status='active'";
        // $this->db->where($where);

        // $array = array('title' => $match, 'page1' => $match, 'page2' => $match); //By Default AND
        // $this->db->like($array); $this->db->or_like($array) //OR 

        //$this->db->order_by('faq_answer', 'DESC');
	}


   function getData($cur_page_no){       

        $review_per_page = $this->perPage(); //get perPage value
        //View field
        $field = array("id","name","profile_img","destination","highlights","slider_image","country","groupsize","position");
        $this->db->select($field); //'*' if you want to select all 'column1,column2'
        $this->db->from('review'); //from review table
        

        //Review active & display according to position
        $this->db->where("active='1'");
		$this->db->order_by('position', 'ASC');
       
        //limit query
        $limit = $review_per_page;        
        $skip = (($cur_page_no-1) * $review_per_page); 

        // if(intval($skip) > 0){
        //    $skip = intval($skip);
        // }else{
        //    $skip = 0;
        // }

  		$this->db->limit($limit,$skip); 

        $query = $this->db->get();
        return $query->result();  //Sending Result in Array Format
   }
  
  //Get Number of Review Has To Show In Per Page
  function perPage(){        
        
   	    $query = $this->db->query("SELECT option_value FROM options WHERE option_name ='review_per_page'");
		$row = $query->row();
		$review_per_page = intval($row->option_value);
        return $review_per_page;

  }
  
  //Get total no of review in database
  function totalRow($table){ 
  	  return $this->db->count_all($table);        
  }

  function totalPage(){
    
        $total_review = $this->totalRow('review');  //Total no. of review
        $per_page = $this->perPage();  //No of review To display per page
        $no_of_pages = $total_review/$per_page;  
        $itr = $no_of_pages - intval($no_of_pages); //if itr is greater than zero than //Even Odd Problem of per page review
        if($itr > 0){
        	$totalpage = intval($no_of_pages)+1;
	    }else{
	        $totalpage = intval($no_of_pages);
	    } 

       return $totalpage; 
  }





}
