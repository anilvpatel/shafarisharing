<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {


	function __construct() {
         
        parent::__construct();  //To load parent construct
        $this->load->helper('url');
        $this->faker = Faker\Factory::create();
        $this->load->model('model_blog', 'm_blog'); //load review modal for database operation

    }

 
   //To remap controller default method //So To Make A Single Page Blog blog/searchblog
	public function _remap($method, $params = array()){
        //$method = 'process_'.$method;
        if (method_exists($this, $method)){

            return call_user_func_array(array($this, $method), $params);

        }elseif(is_numeric($method)){
            $this->index($method, $params);

        }else{
        	$this->singleblog($method,$params);
        }
        //show_404();
    }

    public function index($page = 1,$params= array()){
         
         if(isset($params[0])){
            $type = $params[0];
         }else{
         	 $type = 'all';
         }  
        
        $totalpage = $this->m_blog->totalPage($type);  

        if($page > $totalpage || $page == 0){
        	show_404();
        	exit;
        }

    	$data=array(
           'totalpage' => $totalpage,
           'cur_page_no' => $page,
           'type'	=> $type
    	);
    	
    	$this->load->view('view_blog',$data);
    }

    // public function page($method = 1){
     
    //    $totalpage = $this->m_blog->totalPage();  

    // 	$data=array(
    //        'totalpage' => $totalpage,
    //        'cur_page_no' => $method
    // 	);
    	
    // 	$this->load->view('view_blog',$data); 

    // }
    

    public function singleblog($method,$params){  //$method is url (b_link for single blog)
    	 
    	$blog = $this->m_blog->retrieveSingleBlog($method);

    	if(empty($blog)){
        	show_404();
        	exit;
        }

    	$data = array( 
    		'result' => $blog,
    		'recents' => $this->m_blog->recentBlog(2,$blog->id) //Bring 2 recent blog exculde above blog 
    	);
    	$this->load->view('view_single_blog',$data);
    }



    public function getblogdata($page = 1,$type='all'){ //$page->Page No //$type of category //$type = all means all data
        
        $postdata = json_decode(file_get_contents("php://input"));

        if(!empty($postdata)){
        	$page = $postdata->page;
        	$type = $postdata->type;
        }
       
        

        if(isset($postdata->typelength)){
        	$typelength = $postdata->typelength;
        }else{
        	$typelength = NULL;
        }
       // echo $type; 
        //echo "</br>";
        //$data = json_decode($this->input->raw_input_stream , TRUE); //Take all the post or get data
    	//$postdata = file_get_contents("php://input");
        //$request = json_decode($postdata);
        //var_dump();
        //echo //$this->m_blog->perPage();   
        $result = $this->m_blog->retrieveBlog($page,$type,$typelength); 
        $success = array(
             'status'=>'success',
             'result'=>  $result,
             'length' => count($result),
             'typelength' => $typelength
             
        );
    	 
    	echo json_encode($success);
    }

    public function getblogcategory(){

    	$success = array(
             'status'=>'success',
             'result'=> $this->m_blog->blogCategory('blog_category')
        );

    	echo json_encode($success);
    }


     

   /**
     * seed local database
   */
    public function seed($limit){

    	echo "Its already done!!!";
    	exit;
        // purge existing data
        $this->_truncate_db(); 
        // seed users
        $this->_seed_data($limit); 
        // call more seeds here...
    }


       
    private function _seed_data($limit){
            
        // create a bunch of base buyer accounts
        for ($i = 0; $i < $limit; $i++) {   
            $data = array(
            	'b_category' => rand(1, 3),
                'b_title' => $this->faker->unique()->userName, // get a unique nickname
                'b_link' => $this->faker->unique()->LastName."-".$this->faker->unique()->firstName, 
                'b_excerpt' => 'In fact, so overwhelming is the African safari experience that those who’ve already been there have immortalized their accounts within the pages of books and journals.',            
                'b_content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel, rem, est! Omnis perferendis, nisi obcaecati modi aliquam, neque! Culpa quia, animi itaque numquam praesentium nemo ut repudiandae eius, debitis nulla. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel, rem, est! Omnis perferendis, nisi obcaecati modi aliquam, neque! Culpa quia, animi itaque numquam praesentium nemo ut repudiandae eius, debitis nulla.', 
                'b_f_img' => '1-768x384.png',  
                'b_status' => mt_rand(1, 3), 
                'b_date' => $this->faker->dateTimeThisYear->format('Y-m-d'),
                'b_tags' => $this->faker->state,
                'b_modified' => $this->faker->dateTimeThisYear->format('Y-m-d H:i:s'),
                'b_author_id' => rand(1, 2),
                'b_related_trip' => mt_rand(1, 13).",".mt_rand(1, 13).",".mt_rand(1, 13),
                'b_view' =>  mt_rand(1, 50)                 
            );
 
            $this->m_blog->insertFakeData($data);
        }
 		//$this->session->set_flashdata('message', 'Database Seeds Successfully 25 Records Added In Database');
        echo "Successfully Done!!!";
    }
 
    private function _truncate_db()
    {
        $this->m_blog->truncate();
    }



 

}