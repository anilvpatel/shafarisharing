<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Faq extends CI_Controller {


	function __construct() {

        parent::__construct();  //To load parent construct        
        $this->load->model('model_faq', 'm_faq'); //load review modal for database operation

    }

   public function index()
	{   
        
        $data = array(
              'faq_result'  => $this->m_faq->send_result()

        );
         //Load view & pass $data 
        $this->load->view('view_faq',$data);
	}

}