<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Review extends CI_Controller {


	function __construct() {

        parent::__construct();  //To load parent construct
        //$this->load->helper('url');
        $this->load->model('model_review', 'm_review'); //load review modal for database operation

    }


	public function index(){
       $this->page(1);
	}
	

	public function page($page_no = 1){  //By Default Page No = 1 //Parameter is passed
        
        
        $totalpage = $this->m_review->totalPage();  	 
		 
        //Take Page Number
        //$page_no = $this->uri->segment(3); //SegementBaseURL 1->controller 2-> method 3->parameter 
        $cur_page_no = $page_no;
        //echo $cur_page_no;
        
        
		if(!(is_numeric($cur_page_no) && $cur_page_no <= $totalpage && $cur_page_no != 0)){  //Check weather page_no is given as number 
			$cur_page_no = 1;		
		}

		//Get review data from model		
		$reviewArray = $this->m_review->getData($cur_page_no);  
        
        //Send following data to view page
        $data = array(
              'reviews' => $reviewArray,
              'totalpage' => $totalpage,
              'cur_page_no' => $cur_page_no
        );
        
        //Load view & pass $data 
       $this->load->view('view_review', $data);

	}

	

}