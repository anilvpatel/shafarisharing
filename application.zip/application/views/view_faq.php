<?php $this->load->view('header'); ?>
<?php $asset_url = $this->config->item('assets_url'); 
	  $base_url  = $this->config->item('base_url');  
?>
<header>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 p-0">
				<div class="header-banner-faq">
					<h4 class="font-weight-bold text-white faq-text">IF YOU HAVE ANY QUESTIONS PLEASE LET US KNOW</h4>
					<h5 class="text-center faq-text-p">If you have any questions regarding the unique Safarisharing concept do not hestitate to contact us. But first, please have a look in our FAQ to see if your question is there.</h5>
				</div>
			</div>
		</div>
	</div>
</header>
<div class="container mt-4" id="faq">
	<div class="row">
		<div class="col-md-9">
			<?php //var_dump($faq_result[0]); ?>
			<ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
			<?php foreach ($faq_result as $key => $value) { ?> 
				<li class="nav-item">
					<a class="nav-link <?php if($value->id == 1) echo 'active show ' ?>" id="pills-trip-tab" data-toggle="pill" href="#tab<?php echo $value->id ?>" role="tab" aria-controls="pills-trip" aria-selected="true"><img src="<?php echo $asset_url.'/Icon/'.$value->category_icon; ?>" class="p-lg-5" alt="trip"/></a>
				</li> 
			<?php } ?>
				<!-- <li class="nav-item">
					<a class="nav-link" id="pills-book-tab" data-toggle="pill" href="#pills-book" role="tab" aria-controls="pills-book" aria-selected="false"><img src="<?php echo $asset_url; ?>Icon/Group 2023.png" class="p-lg-5" alt="book"/></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" id="pills-experiance-tab" data-toggle="pill" href="#pills-experiance" role="tab" aria-controls="pills-experiance" aria-selected="false"><img src="<?php echo $asset_url; ?>Icon/Group 2024.png" class="p-lg-5" alt="trip"/></a>
				</li> -->
			</ul>
		</div>
		<div class="col-md-3 mb-3 ml-3 mr-3 mr-md-0 ml-md-0 newsletter">
			<h5 class="font-weight-bold pt-4">Newsletter</h5>
			<p>Receive all the latest news and offers delivered to your inbox!</p>
			<form class="text-center">
				<div class="form-group">
					<input type="email" class="form-control" id="email" placeholder="e-mail address">
					<button type="submit" class="btn btn-primary font-weight-bold text-center mb-2 mt-3">SUBMIT</button>
				</div>
			</form>
		</div>
	</div>
	<div class="row">
		<div class="col-md-9">
			<div class="tab-content" id="pills-tabContent">
				<?php foreach ($faq_result as $fkey => $value) { //active ?> 
				<div class="tab-pane fade <?php if($value->id == 1) echo 'active show ' ?>" id="tab<?php echo $value->id ?>" role="tabpanel" aria-labelledby="pills-trip-tab">
					<h5 class="font-weight-bold"><?php echo $value->category_name ?></h5>
					<p><?php echo $value->category_desc ?></p>
					<div class="panel-group p-3 mb-3" id="accordion" role="tablist" aria-multiselectable="true">
						<?php foreach ($value->QA as $skey => $QA) { ?>
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#Q<?php echo $fkey.$skey ?>" aria-expanded="false" aria-controls="collapseOne">
									&nbsp <?php echo $QA->faq_question ?> 
									</a>
								</p>
							</div>
							<div id="Q<?php echo $fkey.$skey;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseOne">
								<div class="panel-body">
									<?php echo $QA->faq_answer ?> 
								</div>
							</div>
						</div>
						<?php } ?>
						
						<!-- <div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
									&nbsp How can I join a trip? 
									</a>
								</p>
							</div>
							<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseTwo">
								<div class="panel-body">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.le VHS.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseManitoba" aria-expanded="false" aria-controls="collapseManitoba">
									&nbsp How can I create my own trip? 
									</a>
								</p>
							</div>
							<div id="collapseManitoba" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseManitoba">
								<div class="panel-body">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.le VHS.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseBrunswick" aria-expanded="false" aria-controls="collapseBrunswick">
									&nbsp How will Safarisharing offer me the best value? 
									</a>
								</p>
							</div>
							<div id="collapseBrunswick" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseBrunswick">
								<div class="panel-body">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.le VHS.</div>
							</div>
						</div> -->
					</div>
				</div>
			    <?php } ?>
				<!-- <div class="tab-pane fade" id="pills-book" role="tabpanel" aria-labelledby="pills-book-tab">
					<h5 class="font-weight-bold">BOOK & SHARE</h5>
					<p>Book a trip through Safarisharing’s trusted platform and share with other travellers to bring down the price.</p>
					<div class="panel-group p-3 mb-3" id="accordion" role="tablist" aria-multiselectable="true">
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
									&nbsp How does Safarisharing guarantees it’s trusted platform? 
									</a>
								</p>
							</div>
							<div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseFive">
								<div class="panel-body">Safarisharing is an intermediary between customers and local travel partners. We match travellers with available seats in safari trips. We work with a number of partners in all countries where we operate and select the best propositions for our customers and put those trips on our website. All Safarisharing trips are operated by our local partners, but have the Safarisharing label for quality, trust and a unique experience.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
									&nbsp How do I share a trip? 
									</a>
								</p>
							</div>
							<div id="collapseSix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseSix">
								<div class="panel-body">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.le VHS.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
									&nbsp Interesting! But how does sharing with other customers result in a better price for me? 
									</a>
								</p>
							</div>
							<div id="collapseSeven" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseSeven">
								<div class="panel-body">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.le VHS.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
									&nbsp Why do I have to pay the current price and not the lowest price? 
									</a>
								</p>
							</div>
							<div id="collapseEight" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseEight">
								<div class="panel-body">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.le VHS.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
									&nbsp How does the payment process work? 
									</a>
								</p>
							</div>
							<div id="collapseNine" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseNine">
								<div class="panel-body">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.le VHS.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
									&nbsp Can I book a trip for more than one person at the same time? 
									</a>
								</p>
							</div>
							<div id="collapseTen" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseTen">
								<div class="panel-body">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.le VHS.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseEleven" aria-expanded="false" aria-controls="collapseEleven">
									&nbsp I am an East African resident or citizen; will I get a discount to reflect the lower park fees and other rates that can be applicable for residents and citizens? 
									</a>
								</p>
							</div>
							<div id="collapseEleven" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseEleven">
								<div class="panel-body">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.le VHS.</div>
							</div>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="pills-experiance" role="tabpanel" aria-labelledby="pills-experiance-tab">
					<h5 class="font-weight-bold">GO & EXPERIENCE</h5>
					<p> Go on your trip and experience the beauty of Africa with likeminded people.
					</p>
					<div class="panel-group p-3 mb-3" id="accordion" role="tablist" aria-multiselectable="true">
						<div class="panel panel-default">
							<div class="panel-heading" role="tab" id="headingOne">
								<p class="panel-title m-0">
									<a class="collapsed accor-region" data-toggle="collapse" data-parent="#accordion" href="#collapseTwelve" aria-expanded="false" aria-controls="collapseTwelve">
									&nbsp What is the starting point of my trip? 
									</a>
								</p>
							</div>
							<div id="collapseTwelve" class="panel-collapse collapse" role="tabpanel" aria-labelledby="collapseTwelve">
								<div class="panel-body">Safarisharing is an intermediary between customers and local travel partners. We match travellers with available seats in safari trips. We work with a number of partners in all countries where we operate and select the best propositions for our customers and put those trips on our website. All Safarisharing trips are operated by our local partners, but have the Safarisharing label for quality, trust and a unique experience.</div>
							</div>
						</div>
					</div>
				</div> -->
			</div>
		</div>
		<div class="col-md-3 aside-bar">
			<h6 class="font-weight-bold pt-3">Guaranteed Departures</h6>
			<hr class="mb-0">
			<div class="first">
				<ul class="p-0 mt-1">
					<li class="pt-3 pl-1 pr-1"><span class="pt-2">$ 350</span> <span class="right-text">Departure: Oct 31, 18</span></li>
				</ul>
				<img src="<?php echo $asset_url; ?>/images/photo-1516729557409-298ab938f00c.png" class="w-100 pt-2" alt="aside-lion"/>
				<p class="border-bottom text-center font-weight-bold">3 Days Masai Mara Budget Safari</p>
			</div>
			<div class="first">
				<ul class="p-0 mt-1">
					<li class="pt-3 pl-1 pr-1"><span class="pt-2">$ 350</span> <span class="right-text">Departure: Oct 31, 18</span></li>
				</ul>
				<img src="<?php echo $asset_url; ?>/images/alan-james-hendry-1095857-unsplash.png" class="w-100 pt-2" alt="aside-lion"/>
				<p class="border-bottom text-center font-weight-bold">4 Days Masai Mara Lake Nakuru Budget Safari</p>
			</div>
			<div class="first">
				<ul class="p-0 mt-1">
					<li class="pt-3 pl-1 pr-1"><span class="pt-2">$ 350</span> <span class="right-text">Departure: Oct 31, 18</span></li>
				</ul>
				<img src="<?php echo $asset_url; ?>/images/geran-de-klerk-1116923-unsplash.png" class="w-100 pt-2" alt="aside-lion"/>
				<p class="border-bottom text-center font-weight-bold">4 Days Masai Mara Lake Nakuru Budget Safari</p>
			</div>
			<div class="first">
				<ul class="p-0 mt-1">
					<li class="pt-3 pl-1 pr-1"><span class="pt-2">$ 350</span> <span class="right-text">Departure: Oct 31, 18</span></li>
				</ul>
				<img src="<?php echo $asset_url; ?>/images/photo-1513008742681-20111386401d.png" class="w-100 pt-2" alt="aside-lion"/>
				<p class="border-bottom text-center font-weight-bold">8 Days Classic Western Uganda Safari</p>
			</div>
		</div>
	</div>
</div>
<script>
	$(function(){
	$('#accordion .panel-collapse').collapse('toggle');
	});
</script>
<?php $this->load->view('footer.php');?>

