<?php 
$base_url  = $this->config->item('base_url');
$asset_url = $this->config->item('assets_url'); 

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Safari Sharing</title>
    <script type="text/javascript" src="<?php echo $asset_url; ?>/js/jquery-3.3.1.min.js"></script>
    <!--owl carousal-->
    <script type="text/javascript" src="<?php echo $asset_url; ?>/js/owl.carousel.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
    <!--    owl carousal-->
    <link href="<?php echo $asset_url; ?>/css/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo $asset_url; ?>/css/owl.theme.default.min.css" rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo $asset_url; ?>/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="<?php echo $asset_url; ?>/css/mdb.min.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="<?php echo $asset_url; ?>/css/style.css" rel="stylesheet">
    <link href="<?php echo $asset_url; ?>/css/global.css" rel="stylesheet">
  </head>
  <body>
    <header>
      <nav class="navbar navbar-expand-lg navbar-dark primary-color safari-navbar">
        <a class="navbar-brand pl-md-5" href="#">
        <img src="<?php echo $asset_url; ?>/images/logo.png" height="60" alt="safarilogo"/>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
          aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="basicExampleNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">GUARANTEED DEPARTURES
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo $base_url;?>review">REVIEWS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">CONTACT US</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo $base_url;?>faq">FAQ</a>
            </li>
          </ul>
          <!-- Links -->
          <button class="btn btn-md my-2 my-sm-0 customize font-weight-bold" type="submit">CUSTOMIZE YOUR SAFARI
          </button>
        </div>
      </nav>
    </header>
    <main role="main">
