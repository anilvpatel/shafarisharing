<?php $this->load->view('angular_header'); ?>
<?php $asset_url = $this->config->item('assets_url'); 
	  $base_url  = $this->config->item('base_url');  
?> 
<style>
.hidden {
	display: none;
}
</style>
<div id="baseurl" class="hidden"><?php echo $base_url ?></div>
<div id="pageno" class="hidden"><?php echo $cur_page_no; ?></div>
<div id="type" class="hidden"><?php  echo $type;  ?></div>


<link href="<?php echo $asset_url; ?>/css/filtergallery.css" ref="styleesheet">
<main role="main" ng-app="blogapp" ng-controller="blogctrl"> <!-- bring from header.php & it ends in footer.php -->	
<header>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 p-0">
				<div class="header-banner-blog">
					<h4 class="font-weight-bold text-white blog-text">THE SAFARISHARING BLOGS & ARTICLES!</h4>
				</div>
			</div>
		</div>
	</div>
</header>
<div class="container" id="blogs">
	<div id="myBtnContainer" class="text-center p-4">
		<button class="btn btn-grid font-weight-bold {{all ? 'left-btn' : ''}}" ng-click="changeCategory('all')">All</button></a>

		<button class="btn btn-grid font-weight-bold {{c.active ? 'left-btn' : ''}}" ng-repeat="c in category" ng-click="changeCategory(c.category_slug)">{{c.category_name}}</button>
		<!-- <button class="btn btn-grid font-weight-bold" onclick="filterSelection('inspiration')">INSPIRATION</button>
		<button class="btn btn-grid font-weight-bold" onclick="filterSelection('insights')">SAFARISHARING INSIGHTS</button>	 -->	
	</div>
	<div class="row text-center" >
		
		<div ng-repeat="b in blogs" class="col-md-6 column {{b.category_slug}} show mb-2 mt-2" ng-cloak>
			<div class="content">
				<img src="<?php echo $asset_url; ?>/images/{{b.b_f_img}}" class="img-fluid w-100" style="height:350px !important">
				<a href="<?php echo $base_url; ?>blog/{{b.b_link}}"><button type="button" class="btn btn-info read-more font-weight-bold">Read More > ></button></a>
				<div class="box-inner">
					<h6><span class="text-dark font-weight-bold">{{b.category_name}}</span> <br>{{b.b_date | date}}</h6>
					<h6>{{b.b_title}}</h6>
					<p>{{b.b_excerpt}}</span>[…]</p>
				</div>
			</div>
		</div>
<!-- 		<div class=" col-md-6 column tips mb-2 mt-2">
			<div class="content">
				<img src="<?php echo $asset_url; ?>/images/retail-3205035_1280-768x514.png" class="img-fluid w-100">
				<button type="button" class="btn btn-info read-more font-weight-bold">Read More > ></button>
				<div class="box-inner">
					<h6><span class="text-dark font-weight-bold">Tips & Tricks</span> <br>18 MAR 18</h6>
					<h6> 5 Books to read before your African Safari</h6>
					<p>Planning an African Safari? Vishnu Rajamanickam | An unparalleled time awaits you in the land of the Big Five!<span class="small-screen">In fact, so overwhelming is the African safari experience that those who’ve already been there have immortalized their accounts within the pages of books and journals. </span>[…]</p>
				</div>
			</div>
		</div> -->
<!-- 		<div class="col-md-6 column inspiration mb-2 mt-2">
			<div class="content">
				<img src="<?php echo $asset_url; ?>/images/1-768x384.png" class="img-fluid w-100">
				<button type="button" class="btn btn-info read-more font-weight-bold">Read More > ></button>
				<div class="box-inner">
					<h6> <span class="text-dark font-weight-bold">Inspiration</span><br> 4 MAR 18</h6>
					<h6> A Safari in Layman's Terms</h6>
					<p>Marloes Elbertsen | Before I give you a description of the ins and outs of what is a safari, <span class="small-screen">you need to know a little about me. When I was a young kid, my parents believed that children needed to learn how to take care of other living species. Both my brother and I got </span> […]</p>
				</div>
			</div>
		</div> -->
<!-- 		<div class="col-md-6 column insights mb-2 mt-2">
			<div class="content">
				<img src="<?php echo $asset_url; ?>/images/Real-768x768.png" class="img-fluid w-100">
				<button type="button" class="btn btn-info read-more font-weight-bold">Read More > ></button>
				<div class="box-inner">
					<h6><span class="text-dark font-weight-bold"> Safarisharing Insights</span> <br>23 FEb 18</h6>
					<h6> The Real Uganda (Pt.2)-Story of a Volunteering Organisation</h6>
					<p>*This is a 2 part article. Read the first part here. Vishnu Rajamanickam | What strikes volunteers who move to Uganda is how <span class="small-screen"> different life in Uganda is, as compared to living in Europe or North America. “If you have lived long enough in Europe </span>[…]</p>
				</div>
			</div>
		</div> -->
<!-- 		<div class="col-md-6 column insights mb-2 mt-2">
			<div class="content">
				<img src="<?php echo $asset_url; ?>/images/Untitled-design-9-768x576.png" class="img-fluid w-100">
				<button type="button" class="btn btn-info read-more font-weight-bold">Read More > ></button>
				<div class="box-inner">
					<h6><span class="text-dark font-weight-bold"> Safarisharing Insights</span> <br>13 Feb 18</h6>
					<h6> The Real Uganda (Pt.1)- Story of a Volunteering Organisation</h6>
					<p>Vishnu Rajamanickam | Uganda, the country tucked in the depths of East Africa holds a variety of flora and fauna,<span class="small-screen"> alongside a flourishing community with social values so unique that it might sound alien to the far more technologically advanced Western civilization. But</span> […]</p>
				</div>
			</div>
		</div> -->
	</div>
</div>
<!-- <nav aria-label="Page navigation example pagination">
	<ul class="pagination pg-blue justify-content-center">
		<li class="page-item">
			<span class="page-link previous ml-2 mr-2">Previous</span>
		</li>
		<li class="page-item active"><a class="page-link">1</a></li>
		<li class="page-item"><a class="page-link">2</a>
		</li>
		<li class="page-item"><a class="page-link">3</a></li>
		<li class="page-item ml-2 mr-2">
			<a class="page-link next">Next</a>
		</li>
	</ul>
</nav> -->
<nav aria-label="Page navigation example pagination">
  <ul class="pagination pg-blue justify-content-center">
    <li class="page-item ml-2 mr-2">
      <a class="page-link previous" href="<?php if(intval($cur_page_no) > 1){ echo $base_url.'blog/'.($cur_page_no-1).'/'.$type; } ?>" >Previous</a>
    </li>
   <!--  <li class="page-item ml-2 mr-2">
      <a class="page-link" href="+1" ng-disabled="{{ ((pageno-1)>0) ? false: true }}">Previous</a>
    </li> -->

   <!--  <li class="page-item active"><a class="page-link">1</a></li>   -->  
    
    <?php 
    for($i = 0; $i<$totalpage ;$i++){      
      $active = '';
      if($cur_page_no == ($i+1)){
        $active = ' active'; //space Required To Separate Two Classes
      }
      $component  = '<li class="page-item'.$active.'">';
      $hrefurl    = $base_url.'blog/'.($i+1).'/'.$type;
      $component .= '<a class="page-link" href="'.$hrefurl.'">';
      $component .= ($i+1);
      $component .= '</a></li>';
      echo $component;
    }
    ?>   
   <!--  
    <li class="page-item"><a class="page-link">3</a></li> active-link deactive-link later--> 
    <li class="page-item ml-2 mr-2">
      <a class="page-link" href="<?php if(intval($cur_page_no) < $totalpage){ echo $base_url.'blog/'.($cur_page_no+1).'/'.$type;}?>">Next</a>
    </li> 
    <!--  <li class="page-item ml-2 mr-2">
      <a class="page-link" href="{{baseurl+'blog'}}/{{pageno+1}}/{{ctype}}">Next</a>
    </li> -->
  </ul>
</nav>


<!--filter script-->
<script src="<?php  echo $asset_url; ?>/js/js_blog.js"></script>
 


 
<?php $this->load->view('footer.php');?>
 

