<?php $asset_url = $this->config->item('assets_url'); 
	  $base_url  = $this->config->item('base_url');
?>
<footer>
	<div class="desktop">
		<div class="container-fluid">
			<div class="row footer_container">
				<div class="col-md-12">
					<img class="footer_banner" src="<?php echo $asset_url;?>/footer-images/footer_banner.png">
					<div class="container footer_content">
						<div class="row">
							<div class="col-md-3">
								<p class="footer_content_header">QUICK LINKS</p>
								<br>
								<ul>
									<li>About Us</li>
									<li>Contact Us</li>
									<li>Privacy Policy</li>
									<li>Frequently Asked Questions</li>
									<li>Terms & Conditions</li>
									<li><a href="<?php echo $base_url;?>blog">Blogs</a></li>
								</ul>
							</div>
							<div class="col-md-3 need-help">
								<p class="footer_content_header">NEED HELP</p>
								<br>
								<ul>
									<li><img src="<?php echo $asset_url;?>/footer-images/phone.png">+31 6 45985692 NL</li>
									<li><img src="<?php echo $asset_url;?>/footer-images/whatsapp.png">call us on skype</li>
									<li><img src="<?php echo $asset_url;?>/footer-images/mail.png">service@safarisharing.com</li>
									<li><img src="<?php echo $asset_url;?>/footer-images/location.png">Safarisharing b.v. Registered Office Amsterdam Trade registry no. 64513424, Chamber of Commerce Amsterdam, The Netherlands</li>
								</ul>
							</div>
							<div class="col-md-3 footer-form">
								<p class="footer_content_header">CONTACT US</p>
								<br>
								<table class="footer_form">
									<tr>
										<td><input type="text" name="username" placeholder="Name"></td>
									</tr>
									<tr>
										<td><input type="number" name="phone" placeholder="Phone"></td>
									</tr>
									<tr>
										<td><input type="email" name="email" placeholder="Email"></td>
									</tr>
									<tr>
										<td><textarea name="message"  placeholder="Message"></textarea></td>
									</tr>
									<tr>
										<td><button type="submit">Submit</button></td>
									</tr>
								</table>
							</div>
							<div class="col-md-3 followingicons">
								<p class="footer_content_header">FLOW US</p>
								<br>
								<img src="<?php echo $asset_url;?>/footer-images/fb.png">
								<img src="<?php echo $asset_url;?>/footer-images/twitter.png">
								<img src="<?php echo $asset_url;?>/footer-images/insta-black.png">
								<img src="<?php echo $asset_url;?>/footer-images/linkedin.png">
								<div class="text-left">
									<h6 class="font-weight-bold"><span class="border-bottom">SAFARIS BY COUNTRY</span></h6>
									<p class="m-0">KENYA</p>
									<p class="m-0">TANZANIA</p>
									<p class="m-0">UGANDA</p>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<br>
								<p class="allrights">© 2018 SAFARISHARING, all rights reserved. Designed & Developed by Digitalhues</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>
</main>
<!-- SCRIPTS -->
<!-- JQuery -->
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="<?php echo $asset_url;?>/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="<?php echo $asset_url;?>/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="<?php echo $asset_url;?>/js/mdb.min.js"></script>
</body>
</html>
