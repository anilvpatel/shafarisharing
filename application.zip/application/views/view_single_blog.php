<?php $this->load->view('header'); ?> 
<?php $asset_url = $this->config->item('assets_url'); 
	  $base_url  = $this->config->item('base_url');  
?> 
<?php $blogdate=date_create($result->b_date); ?>
<style>
.header-banner-single {
    background-image: linear-gradient(360deg, rgba(28,12,3,0.7) 0%, rgba(248,190,97,0.7) 95%), url(<?php echo $asset_url.'/images/'.$result->b_f_img; ?>);
    height: 322px;
 }
</style>
<!--header-banner-->
<header>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 p-0">
				<div class="header-banner-single">
				</div>
			</div>
		</div>
	</div>
</header>
<div class="container mt-4" id="single-blog">
<div class="row">
	<div class="col-md-9">
		<h5 class="font-weight-bold mt-4"><?php echo $result->b_title; ?></h5>
		<h5 class="mb-4"><span class="inspiration font-weight-bold"> ><?php echo $result->category_name ?></span> <?php echo date_format($blogdate,'M d, Y') ?></h5>
		<p><?php echo html_entity_decode($result->b_content)?></p>
		<div class="col-md-5 followingicons text-center">
			<i class="fas fa-share-alt"></i>
			<img src="<?php echo $asset_url; ?>/Icon/facebook-w.png">
			<img src="<?php echo $asset_url; ?>/Icon/twitter-w.png">
			<img src="<?php echo $asset_url; ?>/Icon/Group 2007.png">
			<img src="<?php echo $asset_url; ?>/Icon/linkedin-w.png">
		</div>
		<div class="col-md-12 text-center">
			<button type="button" class="btn btn-info left-btn font-weight-bold"> << Back to Blogs</button>
		</div>
	</div>
	<div class="col-md-3">
		<div class="newsletter aside-bar p-3 mb-3">
			<h5 class="font-weight-bold pt-4">Newsletter</h5>
			<p>Receive all the latest news and offers delivered to your inbox!</p>
			<form class="text-center">
				<div class="form-group">
					<input type="email" class="form-control" id="email" placeholder="e-mail address">
					<button type="submit" class="btn btn-primary font-weight-bold text-center mb-2 mt-3">SUBMIT</button>
				</div>
			</form>
		</div>
		<div class="aside-bar p-3">
			<h6 class="font-weight-bold pt-3">RECENT POSTS</h6>
			<hr class="mb-0">
			<?php foreach ($recents as $key => $recent) { ?>
				<?php $recentDate = date_create($recent->b_date);?>
                <a href="<?php echo $base_url.'blog/'.$recent->b_link; ?>"><div class="first">
					<ul class="p-0 mt-1">
						<li class="pt-3 pl-1 pr-1 recent-text"><span class="pt-2"><?php echo $recent->category_name ?></span><span class="right-text"><?php echo date_format($recentDate,'M d, y') ?></span></li>
					</ul>
					<img src="<?php echo $asset_url.'/images/'.$recent->b_f_img ?>" class="w-100 pt-2" alt="aside-lion"/>
					<p class="border-bottom text-center font-weight-bold"><?php echo $recent->b_title ?></p>
				</div></a>
			<?php } ?> 
		</div>
		<div class="aside-bar p-3 mt-3">
			<h6 class="font-weight-bold pt-3">RATED SAFARI</h6>
			<hr class="mb-0">
			<div class="first">
				<ul class="p-0 mt-1">
					<li class="pt-3 pl-1 pr-1"><span class="pt-2">$ 350</span> <span class="right-text">Departure: Oct 31, 18</span></li>
				</ul>
				<img src="<?php echo $asset_url; ?>/images/photo-1516729557409-298ab938f00c.png" class="w-100 pt-2" alt="aside-lion"/>
				<p class="border-bottom text-center font-weight-bold">3 Days Masai Mara Budget Safari</p>
			</div>
			<div class="first">
				<ul class="p-0 mt-1">
					<li class="pt-3 pl-1 pr-1"><span class="pt-2">$ 350</span> <span class="right-text">Departure: Oct 31, 18</span></li>
				</ul>
				<img src="<?php echo $asset_url; ?>/images/alan-james-hendry-1095857-unsplash.png" class="w-100 pt-2" alt="aside-lion"/>
				<p class="border-bottom text-center font-weight-bold">4 Days Masai Mara Lake Nakuru Budget Safari</p>
			</div>
		</div>
		<div class="mt-3">
			<div class="first">
				<img src="<?php echo $asset_url; ?>/images/Group 2503.png" class="w-100 pt-2" alt="aside-lion"/>
				<button type="button" class="btn btn-info left-btn singleblog-btn">GUARANTEED DEPARTURES</button>
			</div>
			<div class="first">
				<img src="<?php echo $asset_url; ?>/images/Group 2504.png" class="w-100 pt-2" alt="aside-lion"/>
				<button type="button" class="btn btn-info singleblog-btn1 left-btn">CUSTOMIZE YOUR SAFARI</button>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('footer'); ?> 

