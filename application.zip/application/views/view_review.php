<?php $this->load->view('header'); ?>
<?php $asset_url = $this->config->item('assets_url'); 
      $base_url  = $this->config->item('base_url'); 
?>
<!-- //The member(offset) of an array is convert into variable in view side, 
       so if you send $data['title'] then in view it is access by $title 
--> 
<!-- //If you are sending data as array of array through controller
    like $data = array(
          'title' =>  array(
              'heading' => 'My Heading',
              'message' => 'My Message'
            );
        );
    then use child array offset $member[''] to access in view
    like $title['heading']; 
-->
<!-- //If you are sending data as json encode through controller (json_encode converts array(i.e object) into string)
  like $arrayjson =   array('heading' => 'My Heading', 'message' => 'My Message');
       $json = json_encode($arrayjson);
       $data = array(
          'title' => $json  
       );
  then member of $data array becomes object in view 
  using json_decode as $title = json_decode($title);  (json_decode converts string into object)
  then access by $title->message
 -->  
<!--header-banner-->
<header>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 p-0">
        <div class="header-banner-review">
          <h4 class="font-weight-bold text-white review-text">CHECK OUT WHAT OUR CUSTOMERS HAVE TO SAY!</h4>
        </div>
      </div>
    </div>
  </div>
</header>
<div class="container-fluid mt-4" class="review">
  <div class="col-md-12">
    <h5 class="font-weight-bold mt-4 text-center">EXPERIENCES</h5>
    <hr>
  </div> 



<?php if(!empty($reviews)): ?>
<?php foreach($reviews as $key => $review){ ?>
<div class="row">
    <div class="col-md-7 review-slider-img">
      <div id="carouselExampleControls<?php echo $review->id; ?>" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="<?php echo $asset_url; ?>/images/P1060869-768x512.jpg" class="w-100" alt="review-slider"/>
          </div>
          <div class="carousel-item">
            <img src="<?php echo $asset_url; ?>/images/P1060869-768x512.jpg" class="w-100" alt="review-slider"/>
          </div>
          <div class="carousel-item">
            <img src="<?php echo $asset_url; ?>/images/P1060869-768x512.jpg" class="w-100" alt="review-slider"/>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls<?php echo $review->id; ?>" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"><i class="fas fa-chevron-circle-left"></i></span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls<?php echo $review->id; ?>" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"><i class="fas fa-chevron-circle-right"></i></span>
        </a>
      </div>
    </div>
    <div class="col-md-5 review-slider-text">
      <div class="row">
        <div class="col-md-12 ">
          <i class="fas fa-quote-right"></i>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 col-sm-2 text-center"><i class="fas fa-user-circle"></i></div>
        <div class="col-md-4 col-5 text-justify">
          <p class="font-weight-bold">NAME:</p>
          <p class="font-weight-bold">DESTINATION:</p>
          <p class="font-weight-bold">HIGHLIGHT:</p>
          <p class="font-weight-bold">COUNTRY:</p>
          <p class="font-weight-bold">GROUPSIZE:</p>
        </div>
        <div class="col-md-4 col-5 text-justify">
          <p id="name"><?php echo $review->name; ?></p>
          <p id="desti"><?php echo $review->destination?></p>
          <p id="highlight"><?php echo $review->highlights?></p>
          <p id="country"><?php echo $review->country?></p>
          <p id="groupsize"><?php echo $review->groupsize?></p>
        </div>
      </div>
    </div>
  </div>

<?php } ?>
<?php endif; ?>

  <!-- <div class="row">
    <div class="col-md-7 review-slider-img">
      <div id="carouselExampleControls2" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="<?php echo $asset_url; ?>/images/P1060869-768x512.jpg" class="w-100" alt="review-slider"/>
          </div>
          <div class="carousel-item">
            <img src="<?php echo $asset_url; ?>/images/P1060869-768x512.jpg" class="w-100" alt="review-slider"/>
          </div>
          <div class="carousel-item">
            <img src="<?php echo $asset_url; ?>/images/P1060869-768x512.jpg" class="w-100" alt="review-slider"/>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls2" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"><i class="fas fa-chevron-circle-left"></i></span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls2" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"><i class="fas fa-chevron-circle-right"></i></span>
        </a>
      </div>
    </div>
    <div class="col-md-5 review-slider-text">
      <div class="row">
        <div class="col-md-12 ">
          <i class="fas fa-quote-right"></i>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 col-sm-2 text-center"><i class="fas fa-user-circle"></i></div>
        <div class="col-md-4 col-5 text-justify">
          <p class="font-weight-bold">NAME:</p>
          <p class="font-weight-bold">DESTINATION:</p>
          <p class="font-weight-bold">HIGHLIGHT:</p>
          <p class="font-weight-bold">COUNTRY:</p>
          <p class="font-weight-bold">GROUPSIZE:</p>
        </div>
        <div class="col-md-4 col-5 text-justify">
          <p id="name">Lorem</p>
          <p id="desti">Lorem</p>
          <p id="highlight">Lorem</p>
          <p id="country">Lorem</p>
          <p id="groupsize">Lorem</p>
        </div>
      </div>
    </div>
  </div>
 
</div> -->
<!-- pagination -->
<nav aria-label="Page navigation example pagination">
  <ul class="pagination pg-blue justify-content-center">
    <li class="page-item ml-2 mr-2">
      <a class="page-link previous" href="<?php if(intval($cur_page_no) > 1){ echo $base_url.'review/page/'.($cur_page_no-1); } ?>" >Previous</a>
    </li>


   <!--  <li class="page-item active"><a class="page-link">1</a></li>   -->  
    
    <?php 
    for($i = 0; $i<$totalpage ;$i++){      
      $active = '';
      if($cur_page_no == ($i+1)){
        $active = ' active'; //space Required To Separate Two Classes
      }
      $component  = '<li class="page-item'.$active.'">';
      $hrefurl    = $base_url.'review/page/'.($i+1);
      $component .= '<a class="page-link" href="'.$hrefurl.'">';
      $component .= ($i+1);
      $component .= '</a></li>';
      echo $component;
    }
    ?>   
   <!--  
    <li class="page-item"><a class="page-link">3</a></li> active-link deactive-link later--> 
    <li class="page-item ml-2 mr-2">
      <a class="page-link" href="<?php if(intval($cur_page_no) < $totalpage){ echo $base_url.'review/page/'.($cur_page_no+1);}?>">Next</a>
    </li> 
  </ul>
</nav>
<?php $this->load->view('footer.php');?>

